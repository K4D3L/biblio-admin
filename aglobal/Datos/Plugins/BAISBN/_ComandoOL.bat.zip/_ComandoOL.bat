echo off
start BAISBNOL.exe 9789877183306