echo off
start BAISBNGO.exe 9789877183306