<?php 
include 'conexion.php'; 

// Configuración de Paginación
$resultados_por_pagina = 20;
$pagina = isset($_GET['pag']) ? intval($_GET['pag']) : 1;
if ($pagina < 1) $pagina = 1;
$offset = ($pagina - 1) * $resultados_por_pagina;

// Variables de búsqueda
$buscar = isset($_GET['buscar']) ? $_GET['buscar'] : '';
$criterio = isset($_GET['criterio']) ? $_GET['criterio'] : 'titulo';
$autor_id = isset($_GET['autor_id']) ? intval($_GET['autor_id']) : 0;
$materia_id = isset($_GET['materia_id']) ? intval($_GET['materia_id']) : 0;

// Construcción de la consulta base y contador para paginación
$where_sql = "L.LiActivo = '1'";
$params = "";

if ($autor_id > 0) {
	$where_sql .= " AND L.LiAutor = '$autor_id'";
	$params = "&autor_id=$autor_id";
} elseif ($materia_id > 0) {
	$where_sql .= " AND L.LiMateria = '$materia_id'";
	$params = "&materia_id=$materia_id";
} elseif (!empty($buscar)) {
	$busqueda = $conn->real_escape_string($buscar);
	if ($criterio == 'titulo') {
		$where_sql .= " AND L.LiTitulo LIKE '%$busqueda%'";
	}
	$params = "&buscar=$buscar&criterio=$criterio";
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" type="image/x-icon" href="favicon.ico">
	<title>Biblio-Admin: Buscador</title>
	<style>
		body { font-family: sans-serif; background-color: #f4f4f4; margin: 0; padding: 15px; }
		.container { max-width: 600px; margin: auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
		h2 { color: #333; text-align: center; margin-top: 0; }

		form { display: flex; flex-direction: column; gap: 15px; margin-bottom: 20px; }
		.input-group { display: flex; flex-direction: column; gap: 5px; }
		input, button { padding: 14px; font-size: 16px; border: 1px solid #ddd; border-radius: 6px; }
		button { background-color: #007bff; color: white; border: none; cursor: pointer; font-weight: bold; }
		button:hover { background-color: #0056b3; }

		.search-row { display: flex; gap: 5px; margin-bottom: 15px; }
		.search-row input { flex: 1; min-width: 0;  }
		.search-row button { padding: 0 20px; white-space: nowrap;}

		.autor-click { color: #28a745; text-decoration: none; font-weight: bold; border-bottom: 1px dashed #28a745; }
		.autor-click:hover {  color: #218838; background-color: #f0fff0; }

		/* --- ESTILOS DEL SWITCH (SLICER) --- */
		.switch-container { display: flex; align-items: center; justify-content: center; gap: 12px; font-size: 16px; font-weight: bold; color: #555; user-select: none; background: #eee; padding: 8px; border-radius: 30px; }
		.switch { position: relative; display: inline-block; width: 60px; height: 30px; }
		.switch input { opacity: 0; width: 0; height: 0; }
		.slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #007bff; transition: .3s; border-radius: 34px; }
		.slider:before { position: absolute; content: ""; height: 22px; width: 22px; left: 4px; bottom: 4px; background-color: white; transition: .3s; border-radius: 50%; }
		/* Cuando el checkbox está activo (AUTOR / der) */
		input:checked + .slider { background-color: #28a745; }
		input:checked + .slider:before { transform: translateX(30px); }
		.label-active { color: #333; transition: 0.3s; }
		.label-inactive { color: #aaa; transition: 0.3s; }

		/* --- RESULTADOS --- */
		.card { border: 1px solid #eee; padding: 15px; margin-top: 15px; border-radius: 6px; display: flex; flex-wrap: wrap; gap: 15px; background: #fafafa; }
		.tapa { width: 90px; height: 130px; background: #ddd; object-fit: cover; border-radius: 4px; }
		.info { flex: 1; min-width: 200px; }
		.info h3 { margin: 0 0 5px 0; font-size: 17px; color: #007bff; }
		.info p { margin: 5px 0; font-size: 14px; color: #555; }
		.tag { display: inline-block; background: #e9ecef; padding: 2px 8px; border-radius: 10px; font-size: 12px; }

		/* Lista de Autores */
		.autor-link { display: block; background: #f8f9fa; padding: 15px; margin-top: 8px; border: 1px solid #e2e8f0; border-radius: 6px; text-decoration: none; color: #333; font-weight: bold; font-size: 16px; transition: 0.2s; }
		.autor-link:hover { background: #e2e8f0; color: #28a745; }
		.volver-btn { display: inline-block; margin-bottom: 15px; text-decoration: none; color: #007bff; font-weight: bold; }

		/* Paginación */
		.paginacion { display: flex; justify-content: center; gap: 5px; margin-top: 25px; flex-wrap: wrap; }
		.paginacion a { padding: 8px 14px; background: white; border: 1px solid #ddd; text-decoration: none; color: #007bff; border-radius: 4px; }
		.paginacion a.active { background: #007bff; color: white; border-color: #007bff; }

		/* Links interactivos (Objetos clicables) */
		.link-click { color: #7828a7; text-decoration: none; font-weight: bold; border-bottom: 1px dashed #7828a7; }

	</style>
</head>
<body>

<div class="container">
    <!-- <h2>Buscador de Libros</h2> -->
    
	<form method="GET" action="">
		<div class="search-row">
			<input type="text" name="buscar" placeholder="Buscar..." value="<?php echo htmlspecialchars($buscar); ?>" required>
			<button type="submit">BUSCAR</button>
		</div>

		<div class="switch-container">
			<span id="text-titulo" class="<?php echo ($criterio == 'titulo') ? 'label-active' : 'label-inactive'; ?>">Título</span>
			<label class="switch">
			<input type="checkbox" id="criterio-toggle" <?php echo ($criterio == 'autor') ? 'checked' : ''; ?>>
			<span class="slider"></span>
			</label>
			<span id="text-autor" class="<?php echo ($criterio == 'autor') ? 'label-active' : 'label-inactive'; ?>">Autor</span>
		</div>

		<input type="hidden" name="criterio" id="criterio-hidden" value="<?php echo $criterio; ?>">
	</form>

	<hr style="border: 0; border-top: 1px solid #eee; margin: 20px 0;">

<?php
    // Detectamos si el usuario REALMENTE pidió algo
    $hay_busqueda = (!empty($buscar) || $autor_id > 0 || $materia_id > 0);

    if (!$hay_busqueda) {
        // MENSAJE DE BIENVENIDA (Cuando entran por primera vez)
        echo "<div style='text-align:center; color:#777; margin-top:40px;'>";
        echo "<p>Escribí un título o un autor para comenzar la búsqueda.</p>";
        echo "</div>";
    } 
    elseif (!empty($buscar) && $criterio == 'autor' && $autor_id == 0) {
        // Escenario: El usuario buscó un nombre de autor (le mostramos la lista de autores)
        $busqueda = $conn->real_escape_string($buscar);
        $res_autores = $conn->query("SELECT * FROM ba_autores WHERE AuNombre LIKE '%$busqueda%' ORDER BY AuNombre ASC");
        
        if ($res_autores->num_rows > 0) {
            echo "<h4>Autores encontrados (" . $res_autores->num_rows . "):</h4>";
            while($aut = $res_autores->fetch_assoc()) {
                echo "<a href='index.php?autor_id=".$aut['AuID']."' class='autor-link'>👤 ".$aut['AuNombre']."</a>";
            }
        } else {
            echo "<p style='text-align:center;'>No se encontraron autores con ese nombre.</p>";
        }
    } 
    else {
        // Escenario: Mostrar libros (porque se buscó un título, o se clickeó un autor/materia específico)
        
        // 1. Contamos el total para la paginación (con los filtros aplicados)
        $sql_total = "SELECT COUNT(*) as total FROM ba_libros L 
                      LEFT JOIN ba_autores A ON L.LiAutor = A.AuID 
                      WHERE $where_sql";
        $res_count = $conn->query($sql_total);
        $total_libros = $res_count->fetch_assoc()['total'];
        $total_paginas = ceil($total_libros / $resultados_por_pagina);

        // 2. Traemos los resultados limitados
        $sql_libros = "SELECT L.*, A.AuNombre, M.MaNombre 
                       FROM ba_libros L
                       LEFT JOIN ba_autores A ON L.LiAutor = A.AuID
                       LEFT JOIN ba_materias M ON L.LiMateria = M.MaID
                       WHERE $where_sql
                       ORDER BY L.LiTitulo ASC 
                       LIMIT $offset, $resultados_por_pagina";
        
        $res_libros = $conn->query($sql_libros);

        if ($res_libros->num_rows > 0) {
            # echo "<div style='margin-bottom:10px; font-size:14px; color:#666;'>Mostrando " . $res_libros->num_rows . " de " . $total_libros . " resultados de ( " . $buscar. " )</div>";
            echo "<div style='margin-bottom:10px; font-size:14px; color:#666;'>Mostrando " . $res_libros->num_rows . " de " . $total_libros . " resultados.</div>";
			
            while($row = $res_libros->fetch_assoc()) {
                $img = "../ImgLibro/".$row['LiID'].".jpg";
                if(!file_exists($img)) $img = "../ImgLibro/no_book.jpg";
                ?>
                <div class="card">
                    <img src="<?php echo $img; ?>" class="tapa">
                    <div class="info">
                        <h3><?php echo htmlspecialchars($row['LiTitulo']); ?></h3>
						<p><strong>Número:</strong> <?php echo ($row['LiNumero'] ?? '-'); ?></p>
                        <p><strong>Autor:</strong> <a href="index.php?autor_id=<?php echo $row['LiAutor']; ?>" class="autor-click"><?php echo htmlspecialchars($row['AuNombre'] ?? 'S/D'); ?></a></p>
                        <p><strong>Materia:</strong> <a href="index.php?materia_id=<?php echo $row['LiMateria']; ?>" class="link-click"><?php echo htmlspecialchars($row['MaNombre'] ?? 'S/D'); ?></a></p>
                        <p><strong>Estante:</strong> <?php echo $row['LiEstante']; ?> | <strong>DDC:</strong> <?php echo $row['LiDDC']; ?></p>
                    </div>
                </div>
                <?php
            }

            // Paginación (solo si hay más de una página)
            if ($total_paginas > 1) {
                echo "<div class='paginacion'>";
                // Botón Anterior
                if ($pagina > 1) echo "<a href='index.php?pag=".($pagina-1).$params."'>&laquo;</a>";
                
                // Números de página
                for ($i = 1; $i <= $total_paginas; $i++) {
                    $active = ($i == $pagina) ? "class='active'" : "";
                    echo "<a href='index.php?pag=$i$params' $active>$i</a>";
                }
                
                // Botón Siguiente
                if ($pagina < $total_paginas) echo "<a href='index.php?pag=".($pagina+1).$params."'>&raquo;</a>";
                echo "</div>";
            }
        } else {
            echo "<p style='text-align:center; margin-top:20px;'>No se encontraron resultados para tu búsqueda.</p>";
        }
    }
    ?>
	<p style="text-align: right; font-size: 10px;">By LAB-CD</p>
</div>

<script>
	// Control dinámico del Switch
	const toggle = document.getElementById('criterio-toggle');
	const hiddenInput = document.getElementById('criterio-hidden');
	const textTitulo = document.getElementById('text-titulo');
	const textAutor = document.getElementById('text-autor');

	toggle.addEventListener('change', function() {
		if (this.checked) {
			hiddenInput.value = 'autor';
			textAutor.className = 'label-active';
			textTitulo.className = 'label-inactive';
		} else {
			hiddenInput.value = 'titulo';
			textAutor.className = 'label-inactive';
			textTitulo.className = 'label-active';
		}
	});
</script>

</body>
</html>
