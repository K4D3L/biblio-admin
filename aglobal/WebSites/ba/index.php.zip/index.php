<?php 

// 2. VARIABLES DE CONTROL
$buscar = isset($_GET['buscar']) ? $_GET['buscar'] : '';
$criterio = isset($_GET['criterio']) ? $_GET['criterio'] : 'titulo';
$autor_id = isset($_GET['autor_id']) ? intval($_GET['autor_id']) : 0;
$materia_id = isset($_GET['materia_id']) ? intval($_GET['materia_id']) : 0;

$hay_accion = (!empty($buscar) || $autor_id > 0 || $materia_id > 0);

?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" type="image/x-icon" href="favicon.ico">
	<title>Biblio-Admin: Consultas</title>
	<style>

		body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #0d1117; color: #c9d1d9; margin: 0; padding: 15px; }
		.container { display: flex; flex-direction: column; align-items: center;
		max-width: 350px; margin: auto; background: #161b22; padding: 12px; border-radius: 12px; border: 1px solid #30363d; box-shadow: 0 4px 15px rgba(0,0,0,0.5); }
		
		h2, h3, h4 { color: #58a6ff; }

		.search-row { display: flex; gap: 5px; margin-bottom: 1px; }
		.search-row input { flex: 1; padding: 12px; background: #0d1117; border: 1px solid #30363d; border-radius: 8px; color: #fff; font-size: 16px; outline: none; }
		.search-row input:focus { border-color: #58a6ff; box-shadow: 0 0 5px rgba(88,166,255,0.3); }
		.search-row button { padding: 0 18px; background: #238636; color: white; border: none; border-radius: 8px; font-weight: bold; cursor: pointer; transition: 0.2s; }
		.search-row button:hover { background: #2ea043; }

		.switch-container { display: flex; align-items: center; justify-content: center; gap: 14px; font-size: 24px; font-weight: bold; color: #555; user-select: none; background: #21262d; padding: 10px; border-radius: 10px; border: 1px solid #30363d; }
		.switch { position: relative; display: inline-block; width: 60px; height: 22px; }
		.switch input { opacity: 0; width: 0; height: 0; }
		.slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #30363d; transition: .3s; border-radius: 10px; }
		.slider:before { position: absolute; content: ""; height: 16px; width: 16px; left: 5px; bottom: 3px; background-color: #8b949e; transition: .3s; border-radius: 50%; }
		
		input:checked + .slider { background-color: #1f6feb; }
		input:checked + .slider:before { transform: translateX(34px); background-color: #fff; }
		.label-active { color: #58a6ff; font-weight: bold; transition: 0.3s; }
		.label-inactive { color: #8b949e; transition: 0.3s; }

		.link-clicks { color: #7828a7; text-decoration: none; font-weight: bold; border-bottom: 1px dashed #7828a7; }
		.link-click { color: #79c0ff; text-decoration: none; font-weight: bold; border-bottom: 1px dashed #79c0ff; transition: 0.2s; }
		.link-click:hover { color: #ffa657; border-color: #ffa657; }

		form { display: flex; flex-direction: column; gap: 15px; margin-bottom: 20px; }
		.input-group { display: flex; flex-direction: column; gap: 5px; }
		input, button { padding: 5px; font-size: 16px; border: 1px solid #ddd; border-radius: 6px; }
		button { background-color: #007bff; color: white; border: none; cursor: pointer; font-weight: bold; }
		button:hover { background-color: #0056b3; }
		
		
		.keyspad { display: inline-block; padding: 6px; background-color: #333; border-radius: 10px; width: 281px; }
		.buscar { display: inline-block; padding: 10px; background-color: #333; border-radius: 10px; }

		.display { width: 257px; padding: 10px; font-size: 24px; background-color: #0d1117; border: 2px solid #30363d; color: #fff; text-align: right; border-radius: 8px; margin-bottom: 1px;outline: none; }
		table { margin: 0 auto; }
		.btn { width: 65px; height: 55px; font-size: 26px; background: #21262d; border: 1px solid #30363d; color: #c9d1d9; border-radius: 6px; cursor: pointer; }
		.btn:hover { background: #30363d; }
		.btn-intro { height: 115px; font-size: 20px; background: #238636; color: white; border: none; }
		.btn-intro:hover { background: #2ea043; }
		
	</style>
</head>
<body>

<div class="container">

	<div class="keyspad">
		Numero de Inventario:
		<form method="GET" action="r2.php" id="search-form">
			<input type="text" id="display" name="nInventario" class="display" placeholder="0" readonly required>
			<table>
				<tr>
					<td><button type="button" class="btn" onclick="add('7')">7</button></td>
					<td><button type="button" class="btn" onclick="add('8')">8</button></td>
					<td><button type="button" class="btn" onclick="add('9')">9</button></td>
					<td><button type="button" class="btn" onclick="del()">⌫</button></td>
				</tr>
				<tr>
					<td><button type="button" class="btn" onclick="add('4')">4</button></td>
					<td><button type="button" class="btn" onclick="add('5')">5</button></td>
					<td><button type="button" class="btn" onclick="add('6')">6</button></td>
					<td rowspan="2"><button type="submit" class="btn btn-intro">Intro</button></td>
				</tr>
				<tr>
					<td><button type="button" class="btn" onclick="add('1')">1</button></td>
					<td><button type="button" class="btn" onclick="add('2')">2</button></td>
					<td><button type="button" class="btn" onclick="add('3')">3</button></td>
				</tr>
				<tr>
					<td colspan="2"><button type="button" class="btn" style="width: 135px;" onclick="add('0')">0</button></td>
					<td><button type="button" class="btn" onclick="add('.')">.</button></td>
					<td><button type="button" class="btn" onclick="clearD()">C</button></td>
				</tr>
			</table>
		</form>
	</div>
	
	<br />
	
	<div class="buscar">
		Buscador de Libros:
		<form method="GET" action="r1.php">
			<div class="search-row">
				<input type="text" style="min-width: 80px;" name="buscar" placeholder="Título o Autor..." value="<?php echo htmlspecialchars($buscar); ?>" autocomplete="off" required>
				<button type="submit">BUSCAR</button>
			</div>
			<div class="switch-container">
				<span id="text-titulo" class="<?php echo ($criterio == 'titulo') ? 'label-active' : 'label-inactive'; ?>">Título</span>
				<label class="switch">
					<input type="checkbox" id="criterio-toggle" <?php echo ($criterio == 'autor') ? 'checked' : ''; ?>>
					<span class="slider"></span>
				</label>
				<span id="text-autor" class="<?php echo ($criterio == 'autor') ? 'label-active' : 'label-inactive'; ?>">Autor</span>
			</div>
			<input type="hidden" name="criterio" id="criterio-hidden" value="<?php echo $criterio; ?>">
		</form>
	</div>
	<p style="text-align: right; font-size: 10px;">By LAB-CD</p>
</div>

<script>
	// Control del Teclado Numérico.
    const display = document.getElementById('display');
    function add(n) { display.value += n; }
    function del() { display.value = display.value.slice(0, -1); }
    function clearD() { display.value = ''; }

	// Control dinámico del Switch
	const toggle = document.getElementById('criterio-toggle');
	const hiddenInput = document.getElementById('criterio-hidden');
	const textTitulo = document.getElementById('text-titulo');
	const textAutor = document.getElementById('text-autor');

	toggle.addEventListener('change', function() {
		if (this.checked) {
			hiddenInput.value = 'autor';
			textAutor.className = 'label-active';
			textTitulo.className = 'label-inactive';
		} else {
			hiddenInput.value = 'titulo';
			textAutor.className = 'label-inactive';
			textTitulo.className = 'label-active';
		}
	});
</script>

</body>
</html>
