<?php 
include 'conexion.php';

// 1. CONFIGURACIÓN DE PAGINACIÓN
$resultados_por_pagina = 20;
$pagina = isset($_GET['pag']) ? intval($_GET['pag']) : 1;
if ($pagina < 1) $pagina = 1;
$offset = ($pagina - 1) * $resultados_por_pagina;

// 2. VARIABLES DE CONTROL
$buscar = isset($_GET['buscar']) ? $_GET['buscar'] : '';
$criterio = isset($_GET['criterio']) ? $_GET['criterio'] : 'titulo';
$autor_id = isset($_GET['autor_id']) ? intval($_GET['autor_id']) : 0;
$materia_id = isset($_GET['materia_id']) ? intval($_GET['materia_id']) : 0;

$hay_accion = (!empty($buscar) || $autor_id > 0 || $materia_id > 0);

// 3. CONSTRUIR FILTRO SQL
$where_sql = "L.LiActivo = '1'";
$params = ""; 

if ($autor_id > 0) {
    $where_sql .= " AND L.LiAutor = '$autor_id'";
    $params = "&autor_id=$autor_id";
} elseif ($materia_id > 0) {
    $where_sql .= " AND L.LiMateria = '$materia_id'";
    $params = "&materia_id=$materia_id";
} elseif (!empty($buscar)) {
    $busqueda_limpia = $conn->real_escape_string($buscar);
    if ($criterio == 'titulo') {
        $where_sql .= " AND L.LiTitulo LIKE '%$busqueda_limpia%'";
    }
    $params = "&buscar=" . urlencode($buscar) . "&criterio=$criterio";
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" type="image/x-icon" href="favicon.ico">
	<title>Biblio-Admin: Consultas</title>
    <style>
        /* ESTILO OSCURO NEON */
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #0d1117; color: #c9d1d9; margin: 0; padding: 15px; }
        .container { max-width: 600px; margin: auto; background: #161b22; padding: 20px; border-radius: 12px; border: 1px solid #30363d; box-shadow: 0 4px 15px rgba(0,0,0,0.5); }
        
        h2, h3, h4 { color: #58a6ff; }

        /* Buscador */
        .search-row { display: flex; gap: 8px; margin-bottom: 15px; }
        .search-row input { flex: 1; padding: 12px; background: #0d1117; border: 1px solid #30363d; border-radius: 8px; color: #fff; font-size: 16px; outline: none; }
        .search-row input:focus { border-color: #58a6ff; box-shadow: 0 0 5px rgba(88,166,255,0.3); }
        .search-row button { padding: 0 18px; background: #238636; color: white; border: none; border-radius: 8px; font-weight: bold; cursor: pointer; transition: 0.2s; }
        .search-row button:hover { background: #2ea043; }

        /* Switch Slicer Oscuro */
		.switch-container { display: flex; align-items: center; justify-content: center; gap: 14px; font-size: 16px; font-weight: bold; color: #555; user-select: none; background: #21262d; padding: 10px; border-radius: 10px; border: 1px solid #30363d; }
		.switch { position: relative; display: inline-block; width: 60px; height: 22px; }
		.switch input { opacity: 0; width: 0; height: 0; }
		.slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #30363d; transition: .3s; border-radius: 10px; }
		.slider:before { position: absolute; content: ""; height: 16px; width: 16px; left: 5px; bottom: 3px; background-color: #8b949e; transition: .3s; border-radius: 50%; }
		
		input:checked + .slider { background-color: #1f6feb; }
		input:checked + .slider:before { transform: translateX(34px); background-color: #fff; }
		.label-active { color: #58a6ff; font-weight: bold; transition: 0.3s; }
		.label-inactive { color: #8b949e; transition: 0.3s; }

        /* Tarjetas de Libros */
        .card { border: 1px solid #30363d; padding: 15px; margin-top: 15px; border-radius: 10px; display: flex; gap: 15px; background: #0d1117; transition: 0.3s; }
        .card:hover { border-color: #58a6ff; }
        .tapa { width: 85px; height: 120px; background: #21262d; object-fit: cover; border-radius: 6px; border: 1px solid #30363d; }
		
        /* Contenedor principal de texto */
		.info { flex: 1; display: flex; flex-direction: column; }
        .info h3 { margin: 0; font-size: 16px; color: #58a6ff; }
        .info p { margin: 4px 0; font-size: 15px; color: #8b949e; }
        
        /* Fila inferior para datos (izquierda) y botón (derecha) */
		.info-footer { display: flex; justify-content: space-between; align-items: flex-end; margin-top: auto; gap: 10px; }
        .info-footer p { margin: 0; }

        /* Estilo Botón Detalles */
        .btn-detalle { background-color: #1f6feb; color: #ffffff; border: 1px solid #388bfd; padding: 6px 14px; border-radius: 6px; font-weight: bold; font-size: 13px; cursor: pointer; transition: 0.2s; white-space: nowrap; }
        .btn-detalle:hover { background-color: #388bfd; }

        /* Links Interactivos Neon */
        .link-click { color: #79c0ff; text-decoration: none; font-weight: bold; border-bottom: 1px dashed #79c0ff; transition: 0.2s; }
        .link-click:hover { color: #ffa657; border-color: #ffa657; }
        
        .autor-item { display: block; padding: 14px; background: #161b22; border: 1px solid #30363d; margin-bottom: 8px; border-radius: 8px; text-decoration: none; color: #c9d1d9; font-weight: bold; text-align: left; }
        .autor-item:hover { background: #21262d; border-color: #58a6ff; color: #58a6ff; }

        /* Paginación Dark */
        .paginacion { display: flex; justify-content: center; gap: 8px; margin-top: 25px; flex-wrap: wrap; }
        .paginacion a { padding: 10px 15px; background: #21262d; border: 1px solid #30363d; text-decoration: none; color: #58a6ff; border-radius: 8px; font-size: 14px; }
        .paginacion a.active { background: #1f6feb; color: white; border-color: #1f6feb; }
        
        .volver-btn { display: inline-block; margin-bottom: 15px; text-decoration: none; color: #8b949e; font-size: 16px; border: 1px solid #30363d; padding: 5px 12px; border-radius: 20px; }
        .volver-btn:hover { color: #fff; border-color: #8b949e; }
    </style>
</head>
<body>

<div class="container">

    <form method="GET" action="">
        <div class="search-row">
            <input type="text" name="buscar" placeholder="Título o Autor..." value="<?php echo htmlspecialchars($buscar); ?>" autocomplete="off" required>
            <button type="submit">BUSCAR</button>
        </div>
        
        <div class="switch-container">
            <span id="text-titulo" class="<?php echo ($criterio == 'titulo') ? 'label-active' : 'label-inactive'; ?>">Título</span>
            <label class="switch">
                <input type="checkbox" id="criterio-toggle" <?php echo ($criterio == 'autor') ? 'checked' : ''; ?>>
                <span class="slider"></span>
            </label>
            <span id="text-autor" class="<?php echo ($criterio == 'autor') ? 'label-active' : 'label-inactive'; ?>">Autor</span>
        </div>
        <input type="hidden" name="criterio" id="criterio-hidden" value="<?php echo $criterio; ?>">
    </form>
	<br />
	<a href='index.php' class='volver-btn'>← Volver al Inicio</a>
	
    <?php
    if (!$hay_accion) {
        echo "<div style='text-align:center; padding:40px 0;'>
                <p style='color:#484f58;'>Inicia una búsqueda para explorar la biblioteca.</p>
              </div>";
    } 
    elseif (!empty($buscar) && $criterio == 'autor' && $autor_id == 0) {
        $bus_clean = $conn->real_escape_string($buscar);
        $res_aut = $conn->query("SELECT * FROM ba_autores WHERE AuNombre LIKE '%$bus_clean%' ORDER BY AuNombre ASC");
        
        if ($res_aut->num_rows > 0) {
            echo "<h3>Autores encontrados: (" . $res_aut->num_rows . ") </h3>";
            while($a = $res_aut->fetch_assoc()) {
                echo "<a href='r1.php?autor_id=".$a['AuID']."' class='autor-item'>👤 ".$a['AuNombre']."</a>";
            }
        } else {
            echo "<p style='text-align:center; color:#f85149;'>No se encontró el autor.</p>";
        }
    } 
    else {
        // RESULTADOS
        $tit = "Resultados de: " . $buscar;
        if ($autor_id > 0) {
            $info = $conn->query("SELECT AuNombre FROM ba_autores WHERE AuID = $autor_id")->fetch_assoc();
            $tit = "Libros de: " . ($info['AuNombre'] ?? 'Autor');
			echo "<a href='javascript:history.back()' class='volver-btn'>← Volver</a>";
        } elseif ($materia_id > 0) {
            $info = $conn->query("SELECT MaNombre FROM ba_materias WHERE MaID = $materia_id")->fetch_assoc();
            $tit = "Materia: " . ($info['MaNombre'] ?? 'Materia');
			echo "<a href='javascript:history.back()' class='volver-btn'>← Volver</a>";
        }

        $res_count = $conn->query("SELECT COUNT(*) as total FROM ba_libros L WHERE $where_sql");
        $total_items = $res_count->fetch_assoc()['total'];
        $total_pags = ceil($total_items / $resultados_por_pagina);

        $sql = "SELECT L.*, A.AuNombre, M.MaNombre 
                FROM ba_libros L
                LEFT JOIN ba_autores A ON L.LiAutor = A.AuID
                LEFT JOIN ba_materias M ON L.LiMateria = M.MaID
                WHERE $where_sql
                ORDER BY L.LiTitulo ASC 
                LIMIT $offset, $resultados_por_pagina";
        
        $res = $conn->query($sql);

        if ($res->num_rows > 0) {
			echo "<h3>$tit</h3>";
			echo "<div style='margin-bottom:10px; font-size:14px; color:#666;'>Mostrando " . $res->num_rows . " de " . $total_items . " resultados.</div>";
            while($row = $res->fetch_assoc()) {
                $img = "../ImgLibro/".$row['LiID'].".jpg";
                if(!file_exists($img)) $img = "../ImgLibro/no_book.jpg";
                ?>
                <div class="card">
                    <img src="<?php echo $img; ?>" class="tapa" loading="lazy">
                    <div class="info">
                        <div>
                            <h3><?php echo htmlspecialchars($row['LiTitulo']); ?></h3>
                            <p><strong>Número:</strong> <?php echo ($row['LiNumero'] ?? '-'); ?></p>
                            <p><strong>Autor:</strong> <a href="r1.php?autor_id=<?php echo $row['LiAutor']; ?>" class="link-click"><?php echo htmlspecialchars($row['AuNombre'] ?? 'S/D'); ?></a></p>
                            <p><strong>Materia:</strong> <a href="r1.php?materia_id=<?php echo $row['LiMateria']; ?>" class="link-click"><?php echo htmlspecialchars($row['MaNombre'] ?? 'S/D'); ?></a></p>
							<p><strong>Estante:</strong> <?php echo $row['LiEstante']; ?> | <strong>DDC:</strong> <?php echo $row['LiDDC']; ?></p>
                        </div>
                        
                        <!-- Contenedor inferior con Estante, DDC a la izquierda y Botón de Detalle a la derecha -->
                        <div class="info-footer">
                            <p>&nbsp;</p>
                            <form method="GET" action="r2.php" style="margin: 0;">
                                <input type="hidden" name="nInventario" value="<?php echo $row['LiNumero']; ?>">
                                <button type="submit" class="btn-detalle">Detalles</button>
                            </form>
                        </div>
                    </div>
                </div>
                <?php
            }

            if ($total_pags > 1) {
                echo "<div class='paginacion'>";
                if($pagina > 1) echo "<a href='r1.php?pag=".($pagina-1).$params."'>&laquo;</a>";
                for($i=1; $i<=$total_pags; $i++) {
                    $clase = ($i == $pagina) ? "class='active'" : "";
                    echo "<a href='r1.php?pag=$i$params' $clase>$i</a>";
                }
                if($pagina < $total_pags) echo "<a href='r1.php?pag=".($pagina+1).$params."'>&raquo;</a>";
                echo "</div>";
            }
        } else {
			echo "<p style='text-align:center; color:#f85149;'>No se encontraron libros.</p>";
        }
    }
    ?>
	
	<p style="text-align: right; font-size: 10px;">By LAB-CD</p>
</div>

<script>
    const t = document.getElementById('criterio-toggle'), h = document.getElementById('criterio-hidden');
    t.addEventListener('change', function() {
        h.value = this.checked ? 'autor' : 'titulo';
        document.getElementById('text-titulo').className = this.checked ? 'label-inactive' : 'label-active';
        document.getElementById('text-autor').className = this.checked ? 'label-active' : 'label-inactive';
    });
</script>
</body>
</html>