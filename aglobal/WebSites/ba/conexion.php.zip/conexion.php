<?php
$host = "localhost";
$user = "root";
$pass = "mysql";
$db   = "ba_v8";

$conn = new mysqli($host, $user, $pass, $db);

// Ajuste para caracteres especiales (tildes, ñ)
$conn->set_charset("utf8");

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}
?>