<?php 
include 'conexion.php';

$libro = null;
$mensaje = "";

// Lógica para actualizar Estante, Estado (Activo/Inactivo) y Detalle (POST)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_libro'])) {
    $id_libro = $conn->real_escape_string($_POST['id_libro']);
    $nuevo_estante = $conn->real_escape_string($_POST['li_estante']);
    $nuevo_estado = $conn->real_escape_string($_POST['li_activo']);
    $detalle_estado = $conn->real_escape_string($_POST['li_detalle_activo']);
    
    $sql_update = "UPDATE ba_libros SET 
                    LiEstante = '$nuevo_estante', 
                    LiActivo = '$nuevo_estado', 
                    LiRazon = '$detalle_estado',
                    LiCheck = '1' 
                   WHERE LiID = '$id_libro'";

    if ($conn->query($sql_update)) {
        $mensaje_ok = "Datos del libro actualizados correctamente.";
    } else {
        $mensaje_error = "Error al actualizar: " . $conn->error;
    }
}

// Procesar la búsqueda (GET)
if (isset($_GET['nInventario'])) {
    $nInventario = $conn->real_escape_string($_GET['nInventario']);
    $sql = "SELECT *, 
            (SELECT AuNombre FROM ba_autores WHERE AuID = L.LiAutor) AS AuNombre, 
            (SELECT MaNombre FROM ba_materias WHERE MaID = L.LiMateria) AS MaNombre 
            FROM ba_libros AS L WHERE L.LiNumero = '$nInventario' LIMIT 1";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $libro = $result->fetch_assoc();
    } else {
        $mensaje = "<p style='text-align:center; color:#f85149;'>Sin resultados para el inventario: " . htmlspecialchars($nInventario) . "</p>";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" type="image/x-icon" href="favicon.ico">
	<title>Biblio-Admin: Detalle de Libro</title>
    <style>
		body { font-family: 'Segoe UI', sans-serif; background-color: #0d1117; color: #c9d1d9; margin: 0; padding: 15px; }

		/* Contenedor principal adaptable */
		.container { max-width: 600px; margin: auto; background: #161b22; padding: 15px; border-radius: 12px; border: 1px solid #30363d; text-align: center; }

		/* Card de Resultado */
		.card { background: #0d1117; border: 1px solid #30363d; border-radius: 10px; padding: 15px; display: flex; flex-wrap: wrap; gap: 20px; text-align: left; justify-content: center; }

		/* Columna de Imagen */
		.img-col { display: flex; flex-direction: column; align-items: center; gap: 10px; min-width: 120px; }
		.num-inv { font-weight: bold; color: #58a6ff; font-size: 18px; margin: 0; }
		.tapa { width: 110px; height: 155px; background: #21262d; border-radius: 6px; object-fit: cover; border: 1px solid #30363d; }

		.status-badge { padding: 4px 12px; border-radius: 20px; font-size: 14px; font-weight: bold; text-align: center; }
		.active { background: rgba(35, 134, 54, 0.2); color: #3fb950; border: 1px solid #238636; }
		.inactive { background: rgba(248, 81, 73, 0.2); color: #f85149; border: 1px solid #f85149; }

		/* Columna de Información */
		.info { flex: 1; min-width: 250px; }
		.info h3 { margin: 0 0 12px 0; color: #58a6ff; font-size: 18px; line-height: 1.2; }
		.info p { margin: 6px 0; font-size: 15px; color: #8b949e; }
		.info strong { color: #c9d1d9; }

		/* ESTILOS RESALTADOS PARA PRESTADO */
		.prestado-row { margin: 10px 0 !important; font-size: 15px !important; display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
		
		/* ROJO para prestado */
		.badge-prestado-si { 
			background: rgba(248, 81, 73, 0.2); 
			color: #f85149; 
			border: 1px solid #f85149; 
			padding: 4px 10px; 
			border-radius: 6px; 
			font-weight: bold; 
			font-size: 14px;
			letter-spacing: 0.5px;
			box-shadow: 0 0 8px rgba(248, 81, 73, 0.2);
		}

		/* VERDE para en biblioteca */
		.badge-prestado-no { 
			background: rgba(35, 134, 54, 0.2); 
			color: #3fb950; 
			border: 1px solid #238636; 
			padding: 4px 10px; 
			border-radius: 6px; 
			font-weight: bold; 
			font-size: 14px;
			letter-spacing: 0.5px;
		}

		/* Formularios de edición */
		.edit-form { margin-top: 15px; padding-top: 15px; border-top: 1px dashed #30363d; display: flex; flex-direction: column; gap: 10px; }
		.form-row { display: flex; align-items: center; gap: 10px; }
		
		.input-dark, .select-dark, .textarea-dark { 
			background: #0d1117; 
			border: 1px solid #30363d; 
			color: #fff; 
			padding: 6px 10px; 
			border-radius: 6px; 
			outline: none; 
			font-size: 14px; 
			font-family: inherit;
		}
		.input-estante { width: 70px; }
		.select-dark { cursor: pointer; }
		.textarea-dark { width: 100%; box-sizing: border-box; resize: vertical; min-height: 60px; }
		
		.btn-save { background: #238636; border: none; color: white; padding: 8px 14px; border-radius: 6px; cursor: pointer; font-size: 14px; font-weight: bold; align-self: flex-start; transition: 0.2s; }
		.btn-save:hover { background: #2ea043; }

		.success-msg { color: #3fb950; background: rgba(63, 185, 80, 0.1); padding: 10px; border-radius: 6px; margin-bottom: 15px; font-size: 15px; border: 1px solid #238636; }
		.error-msg-box { color: #f85149; background: rgba(248, 81, 73, 0.1); padding: 10px; border-radius: 6px; margin-bottom: 15px; font-size: 15px; border: 1px solid #f85149; }
		
		.volver-btn { display: inline-block; margin-bottom: 15px; text-decoration: none; color: #8b949e; font-size: 15px; border: 1px solid #30363d; padding: 5px 12px; border-radius: 20px; }
		.volver-btn:hover { color: #fff; border-color: #8b949e; }
	</style>
</head>
<body>

<div class="container">
	<a href='javascript:history.back()' class='volver-btn'>← Volver</a>
    <a href='index.php' class='volver-btn'>← Volver al Inicio</a>
    
    <?php if (isset($mensaje_ok)) echo "<div class='success-msg'>$mensaje_ok</div>"; ?>
    <?php if (isset($mensaje_error)) echo "<div class='error-msg-box'>$mensaje_error</div>"; ?>

    <?php if ($libro):
            $img = "../ImgLibro/".$libro['LiID'].".jpg";
            if(!file_exists($img)) $img = "../ImgLibro/no_book.jpg";
            $es_prestado = ($libro["LiPrestado"] == '1');
            $es_activo = ($libro['LiActivo'] == '1');
    ?>
	<div class="card">
		<div class="img-col">
			<p class="num-inv">Nº <?php echo htmlspecialchars($libro['LiNumero']); ?></p>
			<img src="<?php echo $img; ?>" class="tapa" loading="lazy">
			<?php if ($es_activo): ?>
				<span class="status-badge active">ACTIVO</span>
			<?php else: ?>
				<span class="status-badge inactive">INACTIVO</span>
			<?php endif; ?>
		</div>
                
		<div class="info">
			<h3><?php echo htmlspecialchars($libro['LiTitulo']); ?></h3>
			<p><strong>Autor:</strong> <?php echo htmlspecialchars($libro['AuNombre'] ?? 'S/D'); ?></p>
			<p><strong>Materia:</strong> <?php echo htmlspecialchars($libro['MaNombre'] ?? 'S/D'); ?></p>
			<p><strong>CDD:</strong> <?php echo htmlspecialchars($libro['LiDDC']); ?></p>
			<p><strong>Editorial:</strong> <?php echo htmlspecialchars($libro['LiEditorial']); ?></p>
			
			<!-- Campo Prestado (Rojo si está prestado / Verde si está en biblioteca) -->
			<p class="prestado-row">
				<strong>Prestado:</strong> 
				<?php if ($es_prestado): ?>
					<span class="badge-prestado-si">🔴 SÍ (EN PRÉSTAMO)</span>
				<?php else: ?>
					<span class="badge-prestado-no">🟢 NO (EN BIBLIOTECA)</span>
				<?php endif; ?>
			</p>

			<!-- Formulario de actualización -->
			<form method="POST" class="edit-form">
				<input type="hidden" name="id_libro" value="<?php echo $libro['LiID']; ?>">
				
				<div class="form-row">
					<label><strong>Estante:</strong></label>
					<input type="text" name="li_estante" class="input-dark input-estante" value="<?php echo htmlspecialchars($libro['LiEstante']); ?>" required>
				</div>

				<div class="form-row">
					<label><strong>Estado:</strong></label>
					<select name="li_activo" id="li_activo" class="input-dark select-dark" onchange="toggleMotivo()">
						<option value="1" <?php echo ($es_activo) ? 'selected' : ''; ?>>Activo</option>
						<option value="0" <?php echo (!$es_activo) ? 'selected' : ''; ?>>Inactivo</option>
					</select>
				</div>

				<div id="box-motivo" style="display: <?php echo (!$es_activo) ? 'block' : 'none'; ?>;">
					<label style="display:block; margin-bottom:4px;"><strong>Motivo / Detalle baja:</strong></label>
					<textarea name="li_detalle_activo" id="li_detalle_activo" class="input-dark textarea-dark" placeholder="Especifique el motivo por el cual no está activo..."><?php echo htmlspecialchars($libro['LiRazon'] ?? ''); ?></textarea>
				</div>

				<button type="submit" name="update_libro" class="btn-save">💾 Guardar Cambios</button>
			</form>
		</div>
			
	</div>
    <?php elseif ($mensaje): ?>
	<div class="error-msg-box"><?php echo $mensaje; ?></div>
    <?php endif; ?>
	
	<p style="text-align: right; font-size: 10px;">By LAB-CD</p>
</div>

<script>
function toggleMotivo() {
    const estado = document.getElementById('li_activo').value;
    const boxMotivo = document.getElementById('box-motivo');
    const txtDetalle = document.getElementById('li_detalle_activo');

    if (estado === "0") {
        boxMotivo.style.display = "block";
        
        if (txtDetalle.value.trim() === "") {
            const hoy = new Date();
            const yyyy = hoy.getFullYear();
            const mm = String(hoy.getMonth() + 1).padStart(2, '0');
            const dd = String(hoy.getDate()).padStart(2, '0');
            
            const fechaFormateada = `${yyyy}-${mm}-${dd}`;
            txtDetalle.value = `${fechaFormateada} INACTIVO POR: `;
        }
        txtDetalle.focus();
    } else {
        boxMotivo.style.display = "none";
    }
}
</script>

</body>
</html>