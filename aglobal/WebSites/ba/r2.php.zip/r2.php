<?php 
include 'conexion.php';

$libro = null;
$mensaje = "";

// Lógica para actualizar el estante (POST) [cite: 37]
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_estante'])) {
    $nuevo_estante = $conn->real_escape_string($_POST['li_estante']);
    $id_libro = $conn->real_escape_string($_POST['id_libro']);
    
    $sql_update = "UPDATE ba_libros SET LiEstante = '$nuevo_estante', LiActivo = '1' WHERE LiID = '$id_libro'";
    if ($conn->query($sql_update)) {
        $mensaje_ok = "Estante actualizado correctamente.";
    }
}

// Procesar la búsqueda (GET) [cite: 20]
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['nInventario'])) {
    $nInventario = $conn->real_escape_string($_GET['nInventario']);
    $sql = "SELECT *, 
            (SELECT AuNombre FROM ba_autores WHERE AuID = L.LiAutor) AS AuNombre, 
            (SELECT MaNombre FROM ba_materias WHERE MaID = L.LiMateria) AS MaNombre 
            FROM ba_libros AS L WHERE L.LiNumero = '$nInventario' LIMIT 1";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $libro = $result->fetch_assoc();
    } else {
        $mensaje = "<p style='text-align:center; color:#f85149;'>Sin resultados para el inventario: " . htmlspecialchars($nInventario) . "</p>";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="icon" type="image/x-icon" href="favicon.ico">
	<title>Biblio-Admin: Consultas</title>
    <style>
		body { font-family: 'Segoe UI', sans-serif; background-color: #0d1117; color: #c9d1d9; margin: 0; padding: 5px; }

		/* Contenedor principal adaptable  */
		.container { max-width: 600px; margin: auto; background: #161b22; padding: 10px; border-radius: 12px; border: 1px solid #30363d; text-align: center; }

		/* Card de Resultado con ajuste dinámico  */
		.card { background: #0d1117; border: 1px solid #30363d; border-radius: 10px; padding: 10px; display: flex; flex-wrap: wrap; gap: 20px; text-align: left; justify-content: center; }

		/* Columna de Imagen (Numero arriba, Imagen centro, Estado abajo) [cite: 35] */
		.img-col { display: flex; flex-direction: column; align-items: center; gap: 10px; min-width: 120px; }
		.num-inv { font-weight: bold; color: #58a6ff; font-size: 18px; margin: 0; }
		.tapa { width: 110px; height: 155px; background: #21262d; border-radius: 6px; object-fit: cover; border: 1px solid #30363d; }

		.status-badge { padding: 4px 12px; border-radius: 20px; font-size: 16px; font-weight: bold; text-align: center; }
		.active { background: rgba(35, 134, 54, 0.2); color: #3fb950; border: 1px solid #238636; }
		.inactive { background: rgba(248, 81, 73, 0.2); color: #f85149; border: 1px solid #f85149; }

		/* Columna de Información  */
		.info { flex: 1; min-width: 250px; }
		.info h3 { margin: 0 0 12px 0; color: #58a6ff; font-size: 18px; line-height: 1.2; }
		.info p { margin: 8px 0; font-size: 20px; color: #8b949e; }
		.info strong { color: #c9d1d9; }

		/* Formulario Estante corregido para que no se salga  */
		.shelf-form { display: flex; align-items: center; gap: 8px; margin-top: 5px; flex-wrap: nowrap; }
		.input-estante { background: #0d1117; border: 1px solid #30363d; color: #fff; padding: 6px 10px; border-radius: 6px; width: 60px; outline: none; font-size: 16px; }
		.btn-save { background: #238636; border: none; color: white; padding: 6px 12px; border-radius: 6px; cursor: pointer; font-size: 16px; }
		.btn-save:hover { background: #2ea043; }

		.success-msg { color: #3fb950; background: rgba(63, 185, 80, 0.1); padding: 10px; border-radius: 6px; margin-bottom: 15px; font-size: 20px; }
		.volver-btn { display: inline-block; margin-bottom: 20px; text-decoration: none; color: #8b949e; font-size: 20px; border: 1px solid #30363d; padding: 6px 15px; border-radius: 20px; }
		
	</style>
</head>
<body>

<div class="container">
    <a href='index.php' class='volver-btn'>← Volver al Inicio</a>
    
    <?php if (isset($mensaje_ok)) echo "<a href='javascript:history.back()' class='volver-btn'>← Volver</a> <div class='success-msg'>$mensaje_ok</div>"; ?>

    <?php if ($libro):
            $img = "../ImgLibro/".$libro['LiID'].".jpg";
            if(!file_exists($img)) $img = "../ImgLibro/no_book.jpg";
            $rPrestado = ($libro["LiPrestado"] == '1') ? 'Si' : 'No';
    ?>
	<div class="card">
		<div class="img-col">
			<p class="num-inv">Nº <?php echo htmlspecialchars($libro['LiNumero']); ?></p>
			<img src="<?php echo $img; ?>" class="tapa" loading="lazy">
			<?php if ($libro['LiActivo'] == '1'): ?>
			<span class="status-badge active">ACTIVO</span>
			<?php else: ?>
			<span class="status-badge inactive">INACTIVO</span>
			<?php endif; ?>
		</div>
                
		<div class="info">
			<h3><?php echo htmlspecialchars($libro['LiTitulo']); ?></h3>
			<p><strong>Autor:</strong> <?php echo htmlspecialchars($libro['AuNombre']); ?></p>
			<p><strong>Materia:</strong> <?php echo htmlspecialchars($libro['MaNombre']); ?></p>
			<p><strong>CDD:</strong> <?php echo htmlspecialchars($libro['LiDDC']); ?></p>
			<p><strong>Editorial:</strong> <?php echo htmlspecialchars($libro['LiEditorial']); ?></p>
			<p><strong>Prestado:</strong> <?php echo htmlspecialchars($rPrestado); ?></p>

			<form method="POST" class="shelf-form">
				<p><strong>Estante:</strong></p>
				<input type="hidden" name="id_libro" value="<?php echo $libro['LiID']; ?>">
				<input type="text" name="li_estante" class="input-estante" value="<?php echo htmlspecialchars($libro['LiEstante']); ?>">
				<button type="submit" name="update_estante" class="btn-save" title="Guardar">💾</button>
			</form>
		</div>
			
	</div>
    <?php elseif ($mensaje): ?>
	<div class="error-msg"><?php echo $mensaje; ?></div>
    <?php endif; ?>
	
	<p style="text-align: right; font-size: 10px;">By LAB-CD</p>
</div>

</body>
</html>